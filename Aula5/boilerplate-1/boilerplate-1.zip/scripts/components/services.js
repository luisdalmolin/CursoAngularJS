angular.module('app')
    .factory('GithubService', function() {
        return {

        };
    });
